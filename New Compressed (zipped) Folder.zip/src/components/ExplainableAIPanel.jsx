import { useMemo } from "react";
import RiskMeter from "./RiskMeter.jsx";
import {
  REASON_ICON_MAP,
  AlertTriangleIcon,
  ShieldCheckIcon,
} from "./Icons.jsx";

/**
 * ExplainableAIPanel
 *
 * Props:
 *   text     - the original message text that was scanned
 *   features - explanation items from the API (result.topFeatures). Each item:
 *                { name, value }                                  (old shape, still works)
 *              plus, from the new Flask response (any of these may be missing):
 *                { label, kind, token, direction, impact_pct | impactPct }
 *              value > 0 / direction "phishing"    = pushes toward Spam/Phishing
 *              value < 0 / direction "legitimate"  = pushes toward Legitimate
 *   label    - result.label ("Spam/Phishing" | "Spam" | "Phishing" | "Legitimate")
 *   confidence - result.confidence (0-1), confidence in `label`
 *
 * Optional props (forward these from the backend when you can; the panel
 * derives sensible fallbacks when they are missing):
 *   method               - "SHAP" | "LIME"  (xai_data.method)
 *   phishingProbability  - 0-1, probability of the malicious class
 *   riskLevel            - "Safe" | "Suspicious" | "High Risk"
 *   reliability          - { level: "low" | "normal", note }
 *   redFlags             - plain-English warning signs from the backend:
 *                            [{ key, title, phrases: ["exact text from message", ...] }]
 *                          (Flask sends this as `red_flags`; Spring Boot may
 *                          expose it as `redFlags`.)
 */

// ---------------------------------------------------------------
// Tunable constants
// ---------------------------------------------------------------
// LIME (SMS) / legacy path: raw weights, calibrated as before.
//   REFERENCE_SCALE      = raw weight that fills a bar (strong signal ~0.2)
//   NEGLIGIBLE_THRESHOLD = below this it is sampling noise (noise ~0.03-0.04)
const REFERENCE_SCALE = 0.2;
const NEGLIGIBLE_THRESHOLD = 0.05;

// SHAP (email / URL) path: the backend sends impact_pct = share of the model's
// total attribution, so it is independent of SHAP's units.
//   REFERENCE_SHARE  = a feature carrying this % of the decision fills its bar
//   NEGLIGIBLE_SHARE = below this % it is shown as "minor"
const REFERENCE_SHARE = 30;
const NEGLIGIBLE_SHARE = 4;

const RED = "#f43f5e";
const GREEN = "#34d399";
const AMBER = "#e2a13a";

const BAND_STYLE = {
  "High Risk": {
    color: RED,
    bg: "rgba(244, 63, 94, 0.12)",
    border: "rgba(244, 63, 94, 0.4)",
  },
  Suspicious: {
    color: AMBER,
    bg: "rgba(226, 161, 58, 0.12)",
    border: "rgba(226, 161, 58, 0.4)",
  },
  Safe: {
    color: GREEN,
    bg: "rgba(52, 211, 153, 0.12)",
    border: "rgba(52, 211, 153, 0.4)",
  },
};

// Highlight for phrases that match a warning sign (Highlighted Text card).
const flagHighlightStyle = {
  backgroundColor: "rgba(244, 63, 94, 0.3)",
  border: "1px solid rgba(244, 63, 94, 0.7)",
  borderRadius: 4,
  padding: "0 3px",
};

// ---------------------------------------------------------------
// Categorisation (only used to pick an icon for each reason)
// ---------------------------------------------------------------
const MATCHERS = {
  url: (w) =>
    /^(http|https|www|com|net|org|io|link|click|bit|ly)$/i.test(w) ||
    /^[a-z0-9-]+\.(com|net|org|info|xyz|ru)$/i.test(w),
  urgent: (w) =>
    /^(urgent|verify|immediately|now|act|expire|expires|expired|suspend|suspended|alert|unusual|confirm|blocked|locked|due|limited)$/i.test(
      w,
    ),
  financial: (w) =>
    /^(win|won|prize|free|cash|gift|reward|claim|card|money|bank|account|payment|refund)$/i.test(
      w,
    ),
};

// Engineered (non-word) features from the email and URL models.
const SIGNAL_CATEGORY = {
  has_url: "url",
  is_shortened: "url",
  has_ip: "url",
  num_at: "url",
  num_subdomains: "url",
  num_dots: "url",
  num_hyphens: "url",
  num_subdirs: "url",
  num_params: "url",
  url_length: "url",
  num_digits: "url",
  unique_char_ratio: "url",
  urgency_flag: "urgent",
  suspicious_word_count: "urgent",
};

function categoryOf(item) {
  if (item.direction === "legitimate") return "trusted";
  if (item.kind === "signal") return SIGNAL_CATEGORY[item.name] || "other";
  const w = String(item.token || item.name).toLowerCase();
  if (MATCHERS.url(w)) return "url";
  if (MATCHERS.urgent(w)) return "urgent";
  if (MATCHERS.financial(w)) return "financial";
  return "other";
}

// Accepts both the old {name, value} shape and the new labelled shape,
// snake_case (Flask) or camelCase (Spring Boot).
function normalizeFeature(f) {
  const value = Number(f.value) || 0;
  const name = String(f.name);
  const kind = f.kind || "token";
  return {
    name,
    label: f.label || name,
    kind,
    token: f.token !== undefined ? f.token : kind === "token" ? name : null,
    direction: f.direction || (value > 0 ? "phishing" : "legitimate"),
    value,
    impactPct: f.impact_pct ?? f.impactPct,
  };
}

// ---------------------------------------------------------------
// Styles
// ---------------------------------------------------------------
const cardStyle = {
  background: "var(--panel-bg, #0f1424)",
  border: "1px solid var(--panel-border, #1f2740)",
  borderRadius: 10,
  padding: "16px 18px",
  marginBottom: 14,
};

const cardTitleStyle = {
  fontSize: 13,
  fontWeight: 600,
  color: "#e2e8f0",
  marginBottom: 10,
};

function Legend() {
  const dot = (color) => (
    <span
      style={{
        display: "inline-block",
        width: 8,
        height: 8,
        borderRadius: 999,
        background: color,
        marginRight: 6,
      }}
    />
  );
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: 14,
        fontSize: 11,
        color: "#8b94ab",
        marginBottom: 10,
      }}
    >
      <span>{dot(RED)}pushes toward spam / phishing</span>
      <span>{dot(GREEN)}pushes toward legitimate</span>
    </div>
  );
}

// Escapes a phrase for use inside a RegExp, and lets any run of spaces match
// any whitespace (the panel text may contain line breaks the backend did not).
function phraseToPattern(p) {
  return p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
}

export default function ExplainableAIPanel({
  text,
  features = [],
  label,
  confidence = 0,
  method,
  phishingProbability,
  riskLevel,
  reliability,
  redFlags = [],
  scanType,
}) {
  const flagged = !!label && label.toLowerCase() !== "legitimate";
  const lowInfo = reliability?.level === "low";
  const flags = Array.isArray(redFlags) ? redFlags : [];

  // Normalise every item and give it a scale-independent impact (0-100).
  const items = useMemo(() => {
    const norm = features.map(normalizeFeature);
    // SHAP items carry impact_pct as a share of the whole decision. LIME (and
    // the old API) only have raw weights, so they keep the calibrated
    // raw-weight scale. If `method` isn't forwarded, engineered "signal"
    // items identify the SHAP channels.
    // Old scans loaded from history have no impact_pct, so they always fall
    // back to the raw-weight scale.
    const hasShares = norm.some((i) => i.impactPct != null);
    const isShare =
      hasShares &&
      (method
        ? String(method).toUpperCase() === "SHAP"
        : norm.some((i) => i.kind === "signal"));

    return norm
      .map((i) => {
        const impact = isShare
          ? (i.impactPct ?? 0)
          : Math.min(100, (Math.abs(i.value) / REFERENCE_SCALE) * 100);
        const minor = isShare
          ? impact < NEGLIGIBLE_SHARE
          : Math.abs(i.value) < NEGLIGIBLE_THRESHOLD;
        const barPct = isShare
          ? Math.min(100, (impact / REFERENCE_SHARE) * 100)
          : impact;
        return { ...i, impact, minor, barPct, category: categoryOf(i) };
      })
      .sort((a, b) => b.impact - a.impact);
  }, [features, method]);

  // Reasons must agree with the verdict: flagged -> what pushed toward risk,
  // Legitimate -> what pushed toward safe. Noise-level items are dropped.
  const topReasons = useMemo(() => {
    const want = flagged ? "phishing" : "legitimate";
    return items.filter((i) => i.direction === want && !i.minor).slice(0, 4);
  }, [items, flagged]);

  // Technical details list: only factors that actually carried weight.
  // "Minor" rows and "absence" rows are noise to a normal user.
  const visibleItems = useMemo(
    () => items.filter((i) => !i.minor).slice(0, 6),
    [items],
  );

  // word (lowercase) -> item, strongest item wins. Multi-word n-grams such as
  // "click here" highlight each of their words.
  const highlightMap = useMemo(() => {
    const map = new Map();
    items.forEach((i) => {
      if (!i.token || i.minor) return;
      String(i.token)
        .toLowerCase()
        .split(/\s+/)
        .forEach((w) => {
          if (w && !map.has(w)) map.set(w, i);
        });
    });
    return map;
  }, [items]);

  const tokens = useMemo(() => {
    if (!text) return [];
    return text.split(/(\s+|[.,!?;:()"'])/g).filter((t) => t !== "");
  }, [text]);

  // Splits the text around the red-flag phrases so they can be highlighted.
  // Returns null when there is nothing to highlight (falls back to word-level
  // highlighting from the model).
  const segments = useMemo(() => {
    if (!text) return null;
    const phrases = flags.flatMap((f) => f.phrases || []).filter(Boolean);
    if (phrases.length === 0) return null;
    const pattern = [...phrases]
      .sort((a, b) => b.length - a.length)
      .map(phraseToPattern)
      .join("|");
    try {
      return text
        .split(new RegExp(`(${pattern})`, "gi"))
        .map((part, i) => ({ part, hit: i % 2 === 1 }))
        .filter((s) => s.part !== "");
    } catch {
      return null;
    }
  }, [text, flags]);

  // Risk = probability of the malicious class (backend value if provided).
  const pMalicious =
    phishingProbability != null
      ? Number(phishingProbability)
      : flagged
        ? confidence
        : 1 - confidence;
  const riskValue = Math.max(0, Math.min(100, pMalicious * 100));
  const band =
    riskLevel ||
    (riskValue > 70 ? "High Risk" : riskValue > 30 ? "Suspicious" : "Safe");
  const bandStyle = BAND_STYLE[band] || BAND_STYLE.Suspicious;

  // Wording follows the band, so "Detected" is only used for High Risk.
  const headline =
    band === "High Risk"
      ? `${label} Detected`
      : band === "Suspicious"
        ? flagged
          ? `Possible ${label}`
          : "Likely Legitimate"
        : label;
  const accent = flagged ? bandStyle.color : GREEN;
  const confidencePct = (confidence * 100).toFixed(0);

  const reasoning = useMemo(() => {
    if (lowInfo) {
      return "There was too little content for the model to work with, so treat this score as a weak guess. Try a fuller message.";
    }

    // Plain-English summary built from the warning signs that were found.
    if (flags.length > 0) {
      const parts = flags
        .slice(0, 3)
        .map((f) => f.title.charAt(0).toLowerCase() + f.title.slice(1));
      const list =
        parts.length > 1
          ? `${parts.slice(0, -1).join(", ")} and ${parts[parts.length - 1]}`
          : parts[0];
      const isUrl = scanType === "URL";
      const what = isUrl
        ? "link"
        : scanType === "SMS"
          ? "text message"
          : "message";
      return flagged
        ? `This ${what} ${list}. These are common tactics in phishing and scam ${isUrl ? "links" : "messages"}.`
        : `Marked Legitimate, but this ${what} ${list}. Double-check ${isUrl ? "the link" : "the sender"} before you act on it.`;
    }

    const factors = topReasons
      .slice(0, 2)
      .map((r) => r.label)
      .join("; ");
    if (flagged) {
      return factors
        ? `The model leans ${label} mainly because of: ${factors}.`
        : "The model flagged this message from its overall pattern, but no single word or feature stood out strongly.";
    }
    return factors
      ? `Marked Legitimate. Factors in its favour: ${factors}.`
      : "No strong phishing or spam indicators were found in this message.";
  }, [lowInfo, flagged, label, topReasons, flags, scanType]);

  const wordStyle = (item) => {
    const intensity = Math.min(item.barPct / 100, 1);
    const rgb = item.direction === "phishing" ? "244, 63, 94" : "52, 211, 153";
    return {
      backgroundColor: `rgba(${rgb}, ${0.15 + intensity * 0.45})`,
      border: `1px solid rgba(${rgb}, ${0.4 + intensity * 0.6})`,
      borderRadius: 4,
      padding: "0 3px",
    };
  };

  const signedPct = (item) =>
    `${item.direction === "phishing" ? "+" : "\u2212"}${item.impact.toFixed(0)}%`;

  if (!text) return null;

  const hasHighlights = tokens.some((t) =>
    highlightMap.has(t.trim().toLowerCase()),
  );

  return (
    <div>
      {/* Header */}
      <div style={cardStyle}>
        <div
          style={{
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "space-between",
            gap: 12,
          }}
        >
          <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
            <div
              style={{
                width: 34,
                height: 34,
                borderRadius: 8,
                flexShrink: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: flagged ? bandStyle.bg : "rgba(52, 211, 153, 0.12)",
                color: accent,
              }}
            >
              {flagged ? (
                <AlertTriangleIcon width={18} height={18} />
              ) : (
                <ShieldCheckIcon width={18} height={18} />
              )}
            </div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: accent }}>
                {headline}
              </div>
              <div style={{ fontSize: 13, color: "#8b94ab", marginTop: 2 }}>
                {band === "Suspicious"
                  ? `Leans ${label} \u00b7 Confidence ${confidencePct}%`
                  : `Confidence: ${confidencePct}%`}
              </div>
            </div>
          </div>
          <span
            style={{
              fontSize: 11.5,
              fontWeight: 600,
              padding: "4px 10px",
              borderRadius: 999,
              color: bandStyle.color,
              background: bandStyle.bg,
              border: `1px solid ${bandStyle.border}`,
              whiteSpace: "nowrap",
            }}
          >
            {band}
          </span>
        </div>
      </div>

      {/* Low-information warning */}
      {lowInfo && (
        <div
          style={{
            ...cardStyle,
            display: "flex",
            gap: 10,
            alignItems: "flex-start",
            background: "rgba(226, 161, 58, 0.08)",
            border: "1px solid rgba(226, 161, 58, 0.4)",
          }}
        >
          <span style={{ color: AMBER, flexShrink: 0, marginTop: 1 }}>
            <AlertTriangleIcon width={16} height={16} />
          </span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: AMBER }}>
              Limited analysis
            </div>
            <div
              style={{
                fontSize: 12.5,
                color: "#cbd5e1",
                marginTop: 2,
                lineHeight: 1.5,
              }}
            >
              {reliability?.note ||
                "Too little content to analyse reliably. Treat this result as a weak guess."}
            </div>
          </div>
        </div>
      )}

      {/* Risk Meter */}
      <div style={cardStyle}>
        <div style={{ ...cardTitleStyle, textAlign: "center" }}>Risk Meter</div>
        <RiskMeter value={riskValue} />
      </div>

      {/* Warning signs / Top Reasons */}
      <div style={cardStyle}>
        <div style={cardTitleStyle}>
          {flags.length > 0
            ? flagged
              ? "Warning signs found"
              : "Worth double-checking"
            : flagged
              ? "Why it was flagged"
              : "Why it looks safe"}
        </div>

        {flags.length > 0 ? (
          <div>
            {flags.map((f) => (
              <div key={f.key} style={{ marginBottom: 12 }}>
                <div
                  style={{ fontSize: 13, color: "#e2e8f0", marginBottom: 5 }}
                >
                  {f.title}
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {(f.phrases || []).map((p) => (
                    <span
                      key={p}
                      style={{
                        fontSize: 12,
                        fontFamily: "var(--font-mono)",
                        color: "#fda4af",
                        background: "rgba(244, 63, 94, 0.12)",
                        border: "1px solid rgba(244, 63, 94, 0.35)",
                        borderRadius: 4,
                        padding: "1px 6px",
                      }}
                    >
                      &ldquo;{p}&rdquo;
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : topReasons.length > 0 ? (
          <div>
            {topReasons.map((r) => {
              const { Icon, color } = REASON_ICON_MAP[r.category];
              return (
                <div
                  key={r.name}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    marginBottom: 10,
                  }}
                >
                  <span
                    style={{
                      width: 22,
                      height: 22,
                      flexShrink: 0,
                      borderRadius: 6,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      background: `${color}22`,
                      color,
                    }}
                  >
                    <Icon width={12} height={12} />
                  </span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        fontSize: 12.5,
                        color: "#cbd5e1",
                        marginBottom: 3,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                      title={r.label}
                    >
                      {r.label}
                    </div>
                    <div
                      style={{
                        height: 6,
                        background: "#1a2036",
                        borderRadius: 4,
                        overflow: "hidden",
                      }}
                    >
                      <div
                        style={{
                          width: `${r.barPct}%`,
                          height: "100%",
                          background: color,
                          borderRadius: 4,
                        }}
                      />
                    </div>
                  </div>
                  <span
                    style={{
                      fontSize: 11.5,
                      width: 42,
                      textAlign: "right",
                      flexShrink: 0,
                      color: "#8b94ab",
                      fontFamily: "var(--font-mono)",
                    }}
                  >
                    {signedPct(r)}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ fontSize: 13.5, color: "#8b94ab", lineHeight: 1.5 }}>
            {lowInfo
              ? "Not enough content to point to specific indicators."
              : flagged
                ? "No single indicator stood out. The score reflects the overall pattern of the message."
                : "No suspicious indicators found."}
          </div>
        )}
      </div>

      {/* Technical details (collapsed): what the model weighed */}
      <div style={cardStyle}>
        <details>
          <summary
            style={{
              ...cardTitleStyle,
              cursor: "pointer",
              marginBottom: 0,
            }}
          >
            Technical details: what the model weighed
          </summary>
          <div style={{ marginTop: 12 }}>
            {visibleItems.length === 0 ? (
              <div style={{ fontSize: 13.5, color: "#8b94ab" }}>
                {items.length === 0
                  ? "No detailed breakdown is available for this scan."
                  : "No individual factor was strong enough to list."}
              </div>
            ) : (
              <>
                <Legend />
                {visibleItems.map((f) => {
                  const color = f.direction === "phishing" ? RED : GREEN;
                  return (
                    <div key={f.name} style={{ marginBottom: 8 }}>
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          fontSize: 11.5,
                          color: "#a3adc2",
                          marginBottom: 3,
                        }}
                      >
                        <span
                          style={{
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                          title={f.label}
                        >
                          {f.label}
                        </span>
                        <span
                          style={{
                            fontFamily: "var(--font-mono)",
                            flexShrink: 0,
                            marginLeft: 6,
                          }}
                        >
                          {signedPct(f)}
                        </span>
                      </div>
                      <div
                        style={{
                          height: 8,
                          background: "#1a2036",
                          borderRadius: 4,
                          overflow: "hidden",
                        }}
                        title={`${f.name}: ${f.value.toFixed(4)}`}
                      >
                        <div
                          style={{
                            width: `${Math.max(f.barPct, 2)}%`,
                            height: "100%",
                            background: color,
                            borderRadius: 4,
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
                <div style={{ fontSize: 11, color: "#8b94ab", marginTop: 6 }}>
                  Percentages show each factor&apos;s share of the model&apos;s
                  decision, not a probability.
                </div>
              </>
            )}
          </div>
        </details>
      </div>

      {/* Highlighted Text */}
      <div style={cardStyle}>
        <div style={cardTitleStyle}>Highlighted Text</div>
        {segments ? (
          <div style={{ fontSize: 11, color: "#8b94ab", marginBottom: 10 }}>
            Highlighted phrases are the warning signs listed above.
          </div>
        ) : (
          hasHighlights && <Legend />
        )}
        <div
          style={{
            fontFamily: "monospace",
            fontSize: 13.5,
            lineHeight: 1.9,
            whiteSpace: "pre-wrap",
            color: "#cbd5e1",
          }}
        >
          &ldquo;
          {segments
            ? segments.map((s, i) =>
                s.hit ? (
                  <span key={i} style={flagHighlightStyle}>
                    {s.part}
                  </span>
                ) : (
                  <span key={i}>{s.part}</span>
                ),
              )
            : tokens.map((token, i) => {
                const item = highlightMap.get(token.trim().toLowerCase());
                if (!item || /^\s+$/.test(token)) {
                  return <span key={i}>{token}</span>;
                }
                return (
                  <span key={i} style={wordStyle(item)} title={item.label}>
                    {token}
                  </span>
                );
              })}
          &rdquo;
        </div>
        {!segments && !hasHighlights && (
          <div style={{ fontSize: 12, color: "#8b94ab", marginTop: 8 }}>
            {items.some((i) => i.kind === "token")
              ? "No individual words influenced the result strongly."
              : "This result is driven by overall features (see Technical details), not individual words."}
          </div>
        )}
      </div>

      {/* AI Reasoning */}
      <div
        style={{
          ...cardStyle,
          background:
            "linear-gradient(135deg, rgba(59,130,246,0.12), rgba(139,92,246,0.10))",
          border: "1px solid rgba(99,102,241,0.35)",
        }}
      >
        <div
          style={{
            ...cardTitleStyle,
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <span
            style={{
              width: 22,
              height: 22,
              borderRadius: 6,
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              background: "rgba(99,102,241,0.18)",
              color: "#818cf8",
              fontSize: 12,
            }}
          >
            ✦
          </span>
          AI Reasoning
        </div>
        <div style={{ fontSize: 13.5, color: "#cbd5e1", lineHeight: 1.6 }}>
          {reasoning}
        </div>
      </div>
    </div>
  );
}
